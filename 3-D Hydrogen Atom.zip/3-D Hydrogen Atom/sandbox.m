%http://blogs.mathworks.com/community/2013/06/20/paul-prints-the-l-shaped-membrane/
%http://www.mathworks.com/matlabcentral/fileexchange/42876-surf2solid-make-a-solid-volume-from-a-surface-for-3d-printing
r = 1;
fineness = 10;
x = -r:r/fineness:r;
y = x;
[X,Y] = meshgrid(x,y);
L =  (r - (Y).^2 + (X).^2);
L = L.*(L>0);
L = 0 +(L ).^(1/2);


 figure, subplot(2,2,[1 3]), title 'Thin surface' 
surf(X,Y,L,'EdgeColor','none'); colormap pink; axis image; camlight 
subplot(2,2,2), title 'Block elevation' 
surf2solid(X,Y,L,'elevation',min(Z(:))-0.05); axis image; camlight; camlight 
subplot(2,2,4), title 'Thickness' 
surf2solid(X,Y,L,'thickness',-0.1); axis image; camlight;