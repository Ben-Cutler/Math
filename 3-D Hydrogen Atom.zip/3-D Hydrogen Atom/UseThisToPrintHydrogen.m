[xSpace, ySpace, zSpace, WaveFn, cons] = PrintHydrogen;
WaveFn2 = WaveFn .* conj(WaveFn);

cutoff = .75 * 10^(24);
meters2ang =  10^(-10);
x = xSpace / meters2ang;
y = ySpace / meters2ang;
z = zSpace / meters2ang;
v = WaveFn2 / cutoff;

atomtoprint = isosurface(x,y,z,v,1);
axis equal
stlwrite('atom2.stl',atomtoprint)

fvc = surf2patch(xSpace,ySpace,zSpace,WaveFn,'triangles');
